import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

struct Recipe: Decodable, Identifiable {
	let id: Int
	let title: String
	let featuredImage: String

	private enum CodingKeys: String, CodingKey {
		case id = "pk"
		case title
		case featuredImage = "featured_image"
	}
}

let name: String = "Beef"

let url = URL(string: "https://food2fork.ca/api/recipe/search/?page=2&query=\(name)")!

var request = URLRequest(url: url)
request.addValue("Token 9c8b06d329136da358c2d00e76946b0111ce2c48", forHTTPHeaderField: "Authorization")

let task = URLSession.shared.dataTask(with: request) { data, response, error in
	if let response = response as? HTTPURLResponse, !(200...299).contains(response.statusCode) {
		print(response.statusCode)
	}

	if let error = error {
		print(error.localizedDescription)
	}
	if let data = data, let file = String(data: data, encoding: .utf8) {
		print(file)
	}
}
task.resume()
